import type { ReactNode } from "react";
import { Slack, TriangleAlert } from "lucide-react";
import { AppSidebar } from "@/components/layout/AppSidebar";
import { useAuth } from "@/hooks/useAuth";
import { API_URL } from "@/lib/api";

export function AppShell({ children }: { children: ReactNode }) {
  const { user } = useAuth();

  return (
    <div className="flex min-h-screen bg-background text-foreground">
      <AppSidebar />

      <main className="flex min-w-0 flex-1 flex-col">
        {user && !user.slackConnected ? (
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-primary/20 bg-primary/10 px-6 py-3">
            <div className="flex items-center gap-3">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/20 text-info">
                <TriangleAlert className="h-4 w-4" aria-hidden />
              </span>
              <p className="text-sm text-foreground">
                Slack rate-limit alerts: connect Slack to get notified when sends are throttled.
              </p>
            </div>
            <a
              href={`${API_URL}/auth/slack`}
              className="inline-flex items-center gap-2 rounded-lg border border-info/30 bg-info/10 px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-info transition-colors hover:bg-info/20"
            >
              <Slack className="h-3.5 w-3.5" aria-hidden />
              Connect Slack
            </a>
          </div>
        ) : null}

        <div className="flex-1 overflow-y-auto">{children}</div>
      </main>
    </div>
  );
}
